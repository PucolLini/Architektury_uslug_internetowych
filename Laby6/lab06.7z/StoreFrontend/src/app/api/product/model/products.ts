interface Product {
  id: string;
  name: string;
}

export interface Products {
  products: Product[];
}
