import { Component, OnInit } from '@angular/core';
import { DepartmentService } from '../../service/department/department.service';
import { Officers } from '../../model/officer/officers.model';
import { Department } from '../../model/department/department.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-department',
  standalone: false,
  
  templateUrl: './department.component.html',
  styleUrl: './department.component.css'
})
export class DepartmentComponent implements OnInit {
  departments: Department[] = [];
  officers: Officers | null = null; 
  isEditing: boolean = false; 
  selectedDepartment: Department | null = null; 
  name: string = '';
  city: string = '';
  numberOfCases: number = 0;
  newDepartment = { id: '', name: '', city: '', numberOfCases: 0 };


  constructor(
    private departmentService: DepartmentService,
    private router: Router, //
  ) {}

  ngOnInit(): void {
    this.getAllDepartments(); 
  }

  getDepartmentById(id: string): void {
    this.departmentService.getDepartmentById(id).subscribe((data: Department) => {
      this.selectedDepartment = data;
      this.newDepartment = { ...data }; // form with data in it
      console.log(this.newDepartment);
    }, (error) => {
      console.error("Error fetching department data:", error);
    });
  }

  getAllDepartments(): void {
    this.departmentService.getAllDepartments().subscribe((data: any) => {
      const temp = Array.isArray(data) ? data : Object.values(data);
      this.departments = temp[0];
      console.log(this.departments);
    },
    (error) => {
      console.error("departaments getAll error ", error);
    });
  }

  addDepartment(): void {
    this.departmentService.addDepartment(this.newDepartment).subscribe(() => {
      this.getAllDepartments();
      this.newDepartment = { id: '', name: '', city: '', numberOfCases: 0 };
    });
  }

  updateDepartment(department: Department): void {
    if (this.selectedDepartment) {
      this.departmentService.updateDepartment(department).subscribe(() => {
        this.getAllDepartments();
        this.isEditing = false;
        this.selectedDepartment = null;
        this.newDepartment = { id: '', name: '', city: '', numberOfCases: 0 };
        //
        this.router.navigate(['/departments']);
        //
      }, (error) => {
        console.error("Error updating department:", error);
      });
    }
  }

  editDepartment(department: Department): void {
    this.isEditing = true; 
    this.selectedDepartment = department;
    this.newDepartment = { ...department };
    this.router.navigate([`/departments/edit/${department.id}`]);
    this.getDepartmentById(department.id);  // Fetch department data for the form

  }

  cancelEdit(): void {
    this.isEditing = false;
    this.selectedDepartment = null;
    this.router.navigate(['/departments']); //
  }

  deleteDepartment(id: string): void {
    this.departmentService.deleteDepartment(id).subscribe(() => {
      this.getAllDepartments();
    });
  }
}