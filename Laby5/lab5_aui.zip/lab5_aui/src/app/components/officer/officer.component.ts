import { Component, OnInit } from '@angular/core';
import { OfficerService } from '../../service/officer/officer.service';
import { Officer } from '../../model/officer/officer.model';
import { Department } from '../../model/department/department.model';
import { DepartmentService } from '../../service/department/department.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-officer',
  standalone: false,
  
  templateUrl: './officer.component.html',
  styleUrl: './officer.component.css'
})
export class OfficerComponent implements OnInit {
  officers: Officer[] = []; 
  departments: Department[] = []; 
  isEditingOfficer: boolean = false; 
  selectedOfficer: Officer | null = null; 
  newOfficer: Officer = {
    id: '',
    name: '',
    badgeNumber: 0,
    yearsOfService: 0,
    rank: 0
  };
  departmentId: string = '';
  selectedDepartmentId: string='';

  constructor(private officerService: OfficerService, private departmentService: DepartmentService,
  private router: Router, //
    
  ) {}

  ngOnInit(): void { //inicjalizacja
    this.getAllOfficers();
    this.getAllDepartments(); //dodane
  }

  getAllOfficers(): void {
    this.officerService.getAllOfficers().subscribe((data: any) => {
      const temp = Array.isArray(data) ? data : Object.values(data);
      this.officers = temp[0];
      console.log(this.officers);
    }, (error) => {
      console.error("officers getAll error ", error);
    });
  }

  getAllDepartments(): void {
    this.departmentService.getAllDepartments().subscribe((data: any) => {
      const temp = Array.isArray(data) ? data : Object.values(data);
      this.departments = temp[0];
      console.log("added dept ", this.departments);
    },
    (error) => {  
      console.error(error)
    });
  }

  getOfficerById(id: string): void {
    this.officerService.getOfficerById(id).subscribe((data: Officer) => {
      this.selectedOfficer = data;
      this.newOfficer = { ...data };
      console.log(this.newOfficer);
    }, (error) => {
      console.error("Error fetching officers data:", error);
    });
  }

  getOfficersByDepartmentId(departmentId: string): void {
    this.officerService.getOfficersByDepartmentId(departmentId).subscribe((data: Officer[]) => {
      this.officers = data;
    });
  }

  // createOfficer(officer: Officer, departmentId: string): void {
  //   this.officerService.createOfficer(officer, departmentId).subscribe(() => {
  //     this.getAllOfficers();
  //   });
  // }

  createOfficer(): void {
    if (this.selectedDepartmentId) {
      this.officerService.createOfficer(this.newOfficer, this.selectedDepartmentId).subscribe({
        next: () => {
          this.getAllOfficers();
          this.getAllDepartments();
          this.newOfficer = { id: '', name: '', badgeNumber: 0, yearsOfService: 0, rank: 0 };
        },
        error: (err) => {
          console.error('Failed to create officer:', err);
        },
      });
    } else {
      console.error('Department ID is required to create an officer.');
    }
  }
  
  /*
  createOfficer(): void {
    if (this.departmentId) {
      this.officerService.createOfficer(this.newOfficer, this.departmentId).subscribe(() => {
        this.getAllOfficers();
        this.newOfficer = { id: '', name: '', badgeNumber: 0, yearsOfService: 0, rank: 0 }; 
      });
    }
  }*/

  updateOfficer(officer: Officer): void {
    if (this.selectedOfficer) {
      this.officerService.updateOfficer(officer).subscribe(() => {
        this.getAllOfficers(); 
        this.getAllDepartments();
        this.isEditingOfficer = false;
        this.selectedOfficer = null; 
        this.newOfficer = { id: '', name: '', badgeNumber: 0, yearsOfService: 0, rank: 0 };
        this.router.navigate(['/departments']);
      }, (error) => {
        console.error("Error updating officer:", error);
      });
    }
  }

  editOfficer(officer: Officer): void {
    this.isEditingOfficer = true; 
    this.selectedOfficer = officer; 
    this.newOfficer = { ...officer };
    this.router.navigate([`/officers/edit/${officer.id}`]);
    this.getOfficerById(officer.id);
  }

  cancelEdit(): void {
    this.isEditingOfficer = false;
    this.selectedOfficer = null; 
    this.router.navigate(['/departments']); //
  }

  deleteOfficer(id: string): void {
    this.officerService.deleteOfficer(id).subscribe(() => {
      this.getAllOfficers(); 
      this.getAllDepartments();
    });
  }
}

/*
@Component({
  selector: 'app-officer',
  standalone: false,

  templateUrl: './officer.component.html',
  styleUrl: './officer.component.css' 
})
export class OfficerComponent {
  @Input() officer: Officer = {
    id: '',
    name: '',
    badgeNumber: 0,
    yearsOfService: 0,
    rank: 0
  };
  @Output() submit = new EventEmitter<Officer>();
  @Input() message: string = '';

  onSubmit(): void {
    if (this.officer) {
      this.submit.emit(this.officer);
    }
  }
}*/