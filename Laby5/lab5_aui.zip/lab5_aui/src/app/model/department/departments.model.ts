interface Department {
    id: string;
    name: string;
    city: string;
    numberOfCases: number;
}
export interface Departments {
    departments: Department[];
}