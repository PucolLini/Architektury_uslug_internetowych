interface Officer {
    id: string; 
    name: string;
    badgeNumber?: number; 
    yearsOfService?: number;
    rank?: number; 
}
export interface Officers {
    officers: Officer[];
}