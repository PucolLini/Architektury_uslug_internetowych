import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DepartmentComponent } from './components/department/department.component';
import { OfficerComponent } from './components/officer/officer.component';

const routes: Routes = [
  { path: 'department', component: DepartmentComponent },
  { path: 'officer', component: OfficerComponent },
  { path: 'departments/edit/:id', component: DepartmentComponent },
  { path: 'officers/edit/:id', component: OfficerComponent },
  { path: '', redirectTo: '/department', pathMatch: 'full' }, 
  { path: '**', redirectTo: '/department' }, 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}

