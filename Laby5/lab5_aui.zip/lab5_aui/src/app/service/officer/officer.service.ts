import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Officer } from '../../model/officer/officer.model.js';
import { Department } from '../../model/department/department.model.js';

@Injectable({
  providedIn: 'root',
})
export class OfficerService {
  private baseUrl = 'http://localhost:8080';

  constructor(private httpClient: HttpClient) {}

  getAllOfficers(): Observable<Officer[]> {
    return this.httpClient.get<Officer[]>(`${this.baseUrl}/api/officers`);
  }

  getAllDepartments(): Observable<Department[]> {
    return this.httpClient.get<Department[]>("http://localhost:8080/api/departments");
  }

  getOfficerById(id: string): Observable<Officer> {
    return this.httpClient.get<Officer>(`${this.baseUrl}/api/officers/${id}`);
  }

  getOfficersByDepartmentId(departmentId: string): Observable<Officer[]> {
    return this.httpClient.get<Officer[]>(
      `${this.baseUrl}/api/departments/${departmentId}/officers`,
    );
  }

  createOfficer(officer: Officer, departmentId: string): Observable<Officer> {
    const url = `${this.baseUrl}/api/departments/${departmentId}/officers`;
    const payload = { ...officer, departmentId };
    return this.httpClient.post<Officer>(url, payload);
  }

  updateOfficer(officer: Officer): Observable<Officer> {
    return this.httpClient.put<Officer>(
      `${this.baseUrl}/api/officers/${officer.id}`,
      officer);
  }

  editOfficer(officer: Officer): Observable<Officer> {
    return this.httpClient.put<Officer>(
      `${this.baseUrl}/api/officers/${officer.id}`,
      officer);
  }

  deleteOfficer(id: string): Observable<void> {
    return this.httpClient.delete<void>(`${this.baseUrl}/api/officers/${id}`);
  }
}