import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component'; 
import { HttpClientModule } from '@angular/common/http';
import { OfficerComponent } from './components/officer/officer.component';
import { DepartmentComponent } from './components/department/department.component';
import { OfficerService } from './service/officer/officer.service';  
import { DepartmentService } from './service/department/department.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    OfficerComponent,
    DepartmentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [OfficerService, DepartmentService],
  bootstrap: [AppComponent]
})
export class AppModule { }